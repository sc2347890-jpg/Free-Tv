import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

const base = 'https://iptv-org.github.io/iptv';
// Tab name -> playlist URL (sirf public free streams)
const sources = {
  'India': '$base/countries/in.m3u',
  'News': '$base/categories/news.m3u',
  'Movies': '$base/categories/movies.m3u',
  'Kids': '$base/categories/kids.m3u',
  'Sports': '$base/categories/sports.m3u',
  'Music': '$base/categories/music.m3u',
  'Hindi': '$base/languages/hin.m3u',
  'Tamil': '$base/languages/tam.m3u',
  'Telugu': '$base/languages/tel.m3u',
  'Bengali': '$base/languages/ben.m3u',
  'Marathi': '$base/languages/mar.m3u',
  'Punjabi': '$base/languages/pan.m3u',
  'Malayalam': '$base/languages/mal.m3u',
  'Kannada': '$base/languages/kan.m3u',
};

class Channel {
  final String name, url, logo, group;
  Channel(this.name, this.url, this.logo, this.group);
  Map<String, String> toJson() => {'n': name, 'u': url, 'l': logo, 'g': group};
  factory Channel.fromJson(Map j) => Channel(j['n'], j['u'], j['l'], j['g']);
}

List<Channel> parseM3u(String text) {
  final out = <Channel>[];
  final seen = <String>{};
  String? name, logo, group;
  final attr = RegExp(r'([\w-]+)="(.*?)"');
  for (final raw in const LineSplitter().convert(text)) {
    final l = raw.trim();
    if (l.startsWith('#EXTINF')) {
      final a = {for (final m in attr.allMatches(l)) m.group(1)!: m.group(2)!};
      logo = a['tvg-logo'] ?? '';
      group = a['group-title'] ?? '';
      name = l.substring(l.lastIndexOf(',') + 1).trim();
    } else if (l.startsWith('http') && name != null) {
      if (seen.add(l)) out.add(Channel(name, l, logo ?? '', group ?? ''));
      name = null;
    }
  }
  out.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
  return out;
}

class Repo {
  static final _mem = <String, List<Channel>>{};
  static Future<List<Channel>> load(String url, {bool force = false}) async {
    if (!force && _mem.containsKey(url)) return _mem[url]!;
    final p = await SharedPreferences.getInstance();
    try {
      final r = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 20));
      if (r.statusCode == 200) {
        await p.setString('c_$url', r.body); // offline cache
        return _mem[url] = parseM3u(r.body);
      }
    } catch (_) {}
    final cached = p.getString('c_$url');
    return cached == null ? [] : (_mem[url] = parseM3u(cached));
  }
}

class Store extends ChangeNotifier {
  static final i = Store._();
  Store._();
  List<Channel> favs = [], recent = [];
  Future<void> init() async {
    final p = await SharedPreferences.getInstance();
    favs = _read(p.getString('favs'));
    recent = _read(p.getString('recent'));
    notifyListeners();
  }
  List<Channel> _read(String? s) =>
      s == null ? [] : (jsonDecode(s) as List).map((e) => Channel.fromJson(e)).toList();
  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('favs', jsonEncode(favs.map((e) => e.toJson()).toList()));
    await p.setString('recent', jsonEncode(recent.map((e) => e.toJson()).toList()));
    notifyListeners();
  }
  bool isFav(Channel c) => favs.any((e) => e.url == c.url);
  void toggleFav(Channel c) {
    isFav(c) ? favs.removeWhere((e) => e.url == c.url) : favs.insert(0, c);
    _save();
  }
  void addRecent(Channel c) {
    recent.removeWhere((e) => e.url == c.url);
    recent.insert(0, c);
    if (recent.length > 15) recent.removeLast();
    _save();
  }
}

final themeMode = ValueNotifier<ThemeMode>(ThemeMode.dark);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Store.i.init();
  runApp(const FreeTvApp());
}

class FreeTvApp extends StatelessWidget {
  const FreeTvApp({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ThemeMode>(
        valueListenable: themeMode,
        builder: (_, m, __) => MaterialApp(
          title: 'FreeTV',
          debugShowCheckedModeBanner: false,
          themeMode: m,
          theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.deepOrange),
          darkTheme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.deepOrange, brightness: Brightness.dark),
          home: const Home(),
        ),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final q = ValueNotifier<String>('');
  final tabs = ['Favourites', 'Recent', ...sources.keys];
  bool searching = false;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: tabs.length,
      initialIndex: 2,
      child: Scaffold(
        appBar: AppBar(
          title: searching
              ? TextField(
                  autofocus: true,
                  decoration: const InputDecoration(hintText: 'Channel search...', border: InputBorder.none),
                  onChanged: (v) => q.value = v.toLowerCase(),
                )
              : const Text('FreeTV', style: TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            IconButton(
              icon: const Icon(Icons.brightness_6),
              onPressed: () => themeMode.value = themeMode.value == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark,
            ),
            IconButton(
              icon: Icon(searching ? Icons.close : Icons.search),
              onPressed: () => setState(() {
                searching = !searching;
                q.value = '';
              }),
            ),
          ],
          bottom: TabBar(isScrollable: true, tabAlignment: TabAlignment.start, tabs: [for (final t in tabs) Tab(text: t)]),
        ),
        body: TabBarView(children: [
          ListenableBuilder(listenable: Store.i, builder: (_, __) => ChannelList.static(Store.i.favs, q, 'Koi favourite nahi. Channel par ❤ dabao.')),
          ListenableBuilder(listenable: Store.i, builder: (_, __) => ChannelList.static(Store.i.recent, q, 'Abhi tak kuchh nahi dekha.')),
          for (final u in sources.values) ChannelList.remote(u, q),
        ]),
      ),
    );
  }
}

class ChannelList extends StatefulWidget {
  final String? url;
  final List<Channel>? fixed;
  final ValueNotifier<String> q;
  final String empty;
  const ChannelList.remote(this.url, this.q, {super.key}) : fixed = null, empty = 'Channels nahi mile. Internet check karo.';
  const ChannelList.static(this.fixed, this.q, this.empty, {super.key}) : url = null;
  @override
  State<ChannelList> createState() => _ChannelListState();
}

class _ChannelListState extends State<ChannelList> with AutomaticKeepAliveClientMixin {
  Future<List<Channel>>? f;
  @override
  bool get wantKeepAlive => widget.url != null;
  @override
  void initState() {
    super.initState();
    if (widget.url != null) f = Repo.load(widget.url!);
  }
  Future<void> _refresh() async {
    setState(() => f = Repo.load(widget.url!, force: true));
    await f;
  }
  @override
  Widget build(BuildContext context) {
    super.build(context);
    if (widget.fixed != null) return _list(widget.fixed!);
    return FutureBuilder<List<Channel>>(
      future: f,
      builder: (_, s) {
        if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        return RefreshIndicator(onRefresh: _refresh, child: _list(s.data ?? []));
      },
    );
  }
  Widget _list(List<Channel> all) => ValueListenableBuilder<String>(
        valueListenable: widget.q,
        builder: (_, query, __) {
          final l = query.isEmpty ? all : all.where((c) => c.name.toLowerCase().contains(query)).toList();
          if (l.isEmpty) {
            return ListView(children: [Padding(padding: const EdgeInsets.all(40), child: Center(child: Text(widget.empty, textAlign: TextAlign.center)))]);
          }
          return ListView.builder(
            itemCount: l.length,
            itemBuilder: (_, i) {
              final c = l[i];
              return ListTile(
                leading: SizedBox(
                  width: 52,
                  child: c.logo.isEmpty
                      ? const Icon(Icons.tv, size: 32)
                      : CachedNetworkImage(imageUrl: c.logo, fit: BoxFit.contain, errorWidget: (_, __, ___) => const Icon(Icons.tv, size: 32)),
                ),
                title: Text(c.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: c.group.isEmpty ? null : Text(c.group, maxLines: 1),
                trailing: ListenableBuilder(
                  listenable: Store.i,
                  builder: (_, __) => IconButton(
                    icon: Icon(Store.i.isFav(c) ? Icons.favorite : Icons.favorite_border, color: Colors.redAccent),
                    onPressed: () => Store.i.toggleFav(c),
                  ),
                ),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerPage(l, i))),
              );
            },
          );
        },
      );
}

class PlayerPage extends StatefulWidget {
  final List<Channel> list;
  final int index;
  const PlayerPage(this.list, this.index, {super.key});
  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  late int i = widget.index;
  VideoPlayerController? vc;
  ChewieController? cc;
  bool failed = false;
  Channel get ch => widget.list[i];

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
    _play();
  }

  Future<void> _play() async {
    final oldV = vc, oldC = cc;
    setState(() { failed = false; vc = null; cc = null; });
    oldC?.dispose();
    await oldV?.dispose();
    Store.i.addRecent(ch);
    final v = VideoPlayerController.networkUrl(Uri.parse(ch.url));
    try {
      await v.initialize().timeout(const Duration(seconds: 20));
      if (!mounted) { v.dispose(); return; }
      setState(() {
        vc = v;
        cc = ChewieController(videoPlayerController: v, autoPlay: true, isLive: true, allowFullScreen: true, allowMuting: true,
            deviceOrientationsOnEnterFullScreen: [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight],
            deviceOrientationsAfterFullScreen: [DeviceOrientation.portraitUp]);
      });
    } catch (_) {
      v.dispose();
      if (mounted) setState(() => failed = true);
    }
  }

  void _go(int d) {
    final n = i + d;
    if (n < 0 || n >= widget.list.length) return;
    i = n;
    _play();
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    cc?.dispose();
    vc?.dispose();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(ch.name, overflow: TextOverflow.ellipsis), actions: [
        ListenableBuilder(
          listenable: Store.i,
          builder: (_, __) => IconButton(
            icon: Icon(Store.i.isFav(ch) ? Icons.favorite : Icons.favorite_border, color: Colors.redAccent),
            onPressed: () => Store.i.toggleFav(ch),
          ),
        ),
      ]),
      body: Column(children: [
        AspectRatio(
          aspectRatio: 16 / 9,
          child: Container(
            color: Colors.black,
            child: failed
                ? Center(
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Text('Ye channel abhi chal nahi raha (free streams kabhi band ho jaate hain).', textAlign: TextAlign.center),
                      const SizedBox(height: 8),
                      FilledButton(onPressed: _play, child: const Text('Retry')),
                    ]),
                  )
                : cc == null
                    ? const Center(child: CircularProgressIndicator())
                    : Chewie(controller: cc!),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            OutlinedButton.icon(onPressed: i > 0 ? () => _go(-1) : null, icon: const Icon(Icons.skip_previous), label: const Text('Prev')),
            Text('${i + 1} / ${widget.list.length}'),
            OutlinedButton.icon(onPressed: i < widget.list.length - 1 ? () => _go(1) : null, icon: const Icon(Icons.skip_next), label: const Text('Next')),
          ]),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: widget.list.length,
            itemBuilder: (_, k) => ListTile(
              dense: true,
              selected: k == i,
              title: Text(widget.list[k].name, maxLines: 1, overflow: TextOverflow.ellipsis),
              onTap: () { i = k; _play(); },
            ),
          ),
        ),
      ]),
    );
  }
}
